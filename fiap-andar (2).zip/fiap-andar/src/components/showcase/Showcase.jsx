import React from 'react';
import Input from '../ui/Input';

class Showcase extends React.Component {
    render(){
        return(
            <div className="container">
                <Input icon="search" phText="Busque pela localização desejada." 
                    category="text" />
                <div className="card" style={{width: '18rem'}}>
                    <img src="https://i.imgur.com/q1Mj5mf.jpg" 
                        className="card-img-top" alt="Visão interna" />
                    <div className="card-body">
                        <h5 className="card-title mb-1">Rua Tabapuã</h5>
                        <p className="card-text mt-0">Itaim Bibi - SP</p>
                        <div className="d-flex flex-row mb-4">
                            <i className="fa fa-building-o mr-2" aria-hidden="true" />
                            <p className="mb-0">96 m<sup>2</sup></p>
                            <i className="fa fa-bed mx-2" aria-hidden="true" />
                            <p className="mb-0">2 quartos</p>    
                        </div>
                        <div className="d-flex flex-row justify-content-between align-items-center">
                            <p className="mb-0">11.800,00</p>
                            <a href="#" className="btn btn-primary">
                                <i className="fa fa-info-circle mr-2" />
                                Detalhes
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    
}   

export default Showcase;