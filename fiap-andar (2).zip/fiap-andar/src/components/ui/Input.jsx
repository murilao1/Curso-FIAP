import React from 'react';
import If from '../helpers/If';

class Input extends React.Component {
    render() {
        return(
            <div className="input-group my-4">
                <If test={this.props.icon} >
                    <div className="input-group-prepend">
                        <span className="input-group-text">
                            <i className={"fa fa-" + this.props.icon} />
                        </span>
                    </div>
                </If>
                <input type={this.props.category} 
                    className="form-control"
                    placeholder={this.props.phText}  />
            </div>
        );
    }
}

export default Input;