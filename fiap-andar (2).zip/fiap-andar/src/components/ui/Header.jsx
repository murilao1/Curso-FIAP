import React from 'react';

class Header extends React.Component{
    render(){
        return (
            <nav className="navbar navbar-dark bg-info">
                <a className="navbar-brand d-flex flex-row " href="#">
                <i className="fa fa-home fa-2x mr-2 " aria-hidden="true" />
                    <h3>FIAP Andar</h3>
                </a>
            </nav>
        );
    }
}   

export default Header;