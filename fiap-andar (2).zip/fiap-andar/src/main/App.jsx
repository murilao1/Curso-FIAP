import 'bootstrap/dist/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';
import './App.css';

import 'jquery/dist/jquery.min';

import React from 'react';

import Header from '../components/ui/Header';
import Showcase from '../components/showcase/Showcase';


const App = () => (
    <>
        <Header />
        <Showcase />
    </>
)

export default App;